import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TcontolController } from './tcontol/tcontol.controller';
import { TmodulModule } from './tmodul/tmodul.module';

@Module({
  imports: [TmodulModule],
  controllers: [AppController, TcontolController],
  providers: [AppService],
})
export class AppModule {}
