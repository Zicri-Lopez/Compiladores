import { Module } from '@nestjs/common';
import { TcontolController } from 'src/tcontol/tcontol.controller';

@Module({
imports:[],
controllers:[TcontolController],
providers:[]
})
export class TmodulModule {}
