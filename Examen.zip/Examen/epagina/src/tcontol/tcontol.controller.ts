import { Controller } from '@nestjs/common';

@Controller('tcontol')
export class TcontolController {}
