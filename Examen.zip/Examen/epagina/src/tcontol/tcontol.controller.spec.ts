import { Test, TestingModule } from '@nestjs/testing';
import { TcontolController } from './tcontol.controller';

describe('TcontolController', () => {
  let controller: TcontolController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TcontolController],
    }).compile();

    controller = module.get<TcontolController>(TcontolController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
