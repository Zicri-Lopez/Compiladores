import {Inject, Injectable } from '@nestjs/common';
import { ClientProxy} from '@nestjs/microservices'

@Injectable()
export class AppService {
  constructor(@Inject('MAIL_SERVICE')private clienMail: ClientProxy) {}

  getHello(): string{
    return'soy el app pricipal en el puerto 3000';
  }
  newUser(user:any){
  this.clienMail.emit('new_mail',user); 
  return 'send_queue'
  }
}
