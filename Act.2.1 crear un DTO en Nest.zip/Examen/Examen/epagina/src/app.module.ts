import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { BmController } from './bm/bm.controller';
import { BmModule } from './bm/bm.module';
import { BmService } from './bm/bm.service';


@Module({
  imports: [BmModule],
  controllers: [AppController,BmController],
  providers: [AppService,BmService],
})
export class AppModule {}
