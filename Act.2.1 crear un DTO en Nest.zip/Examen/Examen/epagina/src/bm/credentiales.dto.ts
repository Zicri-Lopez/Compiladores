export class CredentialsDto{
    Identificador: string;
    Usuario: string;
    Contraseña: string;
}