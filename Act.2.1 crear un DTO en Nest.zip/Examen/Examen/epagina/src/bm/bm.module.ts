import { Module } from '@nestjs/common';
import { BmService } from './bm.service';

@Module({
  providers: [BmService]
})
export class BmModule {}
