export interface CredentialsDto {
    Identificador: string;
    Usuaraio: string;
    Contraseña: string; 
}
