import { Test, TestingModule } from '@nestjs/testing';
import { BmController } from './bm.controller';

describe('BmController', () => {
  let controller: BmController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [BmController],
    }).compile();

    controller = module.get<BmController>(BmController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});