import { Controller, Get, Post, Put, Delete, Req, Patch, Body, Param } from '@nestjs/common';
import { CredentialsDto } from './credentiales.dto';

@Controller('api/v1/bm')
export class BmController {

    @Post('id/:Id/User/:user/Password/:password')
    metedopost(@Param('Id') Identificador: string, @Param('user') Usuario: string, @Param('password') Contraseña: string, @Body() credentialsDto: CredentialsDto) {
        console.log('Identificador:', Identificador);
        console.log('Usuario:', Usuario);
        console.log('Contraseña:', Contraseña);
        
        return { Identificador: Identificador, Usuario, Contraseña  }; 
    }

    @Get('getruta') 
    getMethod(@Req() req: Request) {
        return `método ${req.method}`;
    }

    @Put()
    metodoput(@Req() req: Request) {
        return `método ${req.method}`;
    }
    
    @Delete()
    metododelete(@Req() req: Request) {
        return `método ${req.method}`;
    }

    @Patch()
    metodopatch(@Req() req: Request) {
        return `método ${req.method}`;
    }
}
