import { Test, TestingModule } from '@nestjs/testing';
import { BmService } from './bm.service';

describe('BmService', () => {
  let service: BmService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [BmService],
    }).compile();

    service = module.get<BmService>(BmService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});